<?php
require 'config.php';

// Get recent orders
$stmt = $pdo->query("SELECT * FROM orders ORDER BY order_date DESC LIMIT 5");
$recent_orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get active payment plans with corrected calculations
$stmt = $pdo->query("
    SELECT 
        pp.plan_id, 
        pp.customer_name, 
        pp.total_amount, 
        pp.downpayment, 
        pp.balance,
        pp.daily_payment,
        pp.release_date,
        COALESCE(SUM(p.amount_paid), 0) as total_paid,
        (pp.balance - COALESCE(SUM(p.amount_paid), 0)) as remaining_balance
    FROM payment_plans pp 
    LEFT JOIN payments p ON pp.plan_id = p.plan_id 
    GROUP BY pp.plan_id 
    ORDER BY pp.release_date DESC 
    LIMIT 5
");
$active_plans = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate summary stats with proper validation
$stmt = $pdo->query("SELECT COUNT(*) as total_orders FROM orders");
$total_orders = $stmt->fetchColumn() ?: 0;

$stmt = $pdo->query("SELECT COUNT(*) as total_plans FROM payment_plans");
$total_plans = $stmt->fetchColumn() ?: 0;

$stmt = $pdo->query("SELECT SUM(total_amount) as total_revenue FROM payment_plans");
$total_revenue = $stmt->fetchColumn() ?: 0;

$stmt = $pdo->query("SELECT SUM(amount_paid) as total_collected FROM payments");
$total_collected = $stmt->fetchColumn() ?: 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delute Welding Shop - Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="wrapper">
    <!-- Sidebar -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <h3>Delute Welding Shop</h3>
            <p>Management System</p>
        </div>

        <div class="sidebar-menu">
            <ul class="list-unstyled components">
                <li class="active">
                    <a href="index.php">
                        <i class="bi bi-speedometer2"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="orders/orders.php">
                        <i class="bi bi-clipboard-check"></i>
                        <span>Orders</span>
                    </a>
                </li>
                <li>
                    <a href="payments/index.php">
                        <i class="bi bi-cash-stack"></i>
                        <span>Payments</span>
                    </a>
                </li>
                <li>
                    <a href="reports.php">
                        <i class="bi bi-graph-up"></i>
                        <span>Reports</span>
                    </a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Page Content -->
    <div id="content">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="mb-0">Dashboard</h1>                   
                    <span class="badge bg-primary">
                        <?= date('F j, Y') ?>
                    </span>
                </div>
            </div>

            <!-- Stats Cards -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <div class="icon mb-3">
                                <i class="bi bi-clipboard-data fs-1 text-primary"></i>
                            </div>
                            <h6 class="card-title text-muted">Total Orders</h6>
                            <h3 class="mb-0"><?= number_format($total_orders) ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <div class="icon mb-3">
                                <i class="bi bi-credit-card fs-1 text-info"></i>
                            </div>
                            <h6 class="card-title text-muted">Active Plans</h6>
                            <h3 class="mb-0"><?= number_format($total_plans) ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <div class="icon mb-3">
                                <i class="bi bi-currency-dollar fs-1 text-success"></i>
                            </div>
                            <h6 class="card-title text-muted">Total Revenue</h6>
                            <h3 class="mb-0"><?= format_currency($total_revenue) ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <div class="icon mb-3">
                                <i class="bi bi-cash fs-1 text-warning"></i>
                            </div>
                            <h6 class="card-title text-muted">Total Collected</h6>
                            <h3 class="mb-0"><?= format_currency($total_collected) ?></h3>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h3 class="mb-0">Recent Orders</h3>
                            <a href="orders/orders.php" class="btn btn-sm btn-primary">View All</a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Customer</th>
                                            <th>Date</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($recent_orders as $order): ?>
                                            <tr>
                                                <td><?= $order['order_id'] ?></td>
                                                <td><?= htmlspecialchars($order['customer_name']) ?></td>
                                                <td><?= date('M j, Y', strtotime($order['order_date'])) ?></td>
                                                <td><?= get_status_badge($order['status']) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h3 class="mb-0">Active Payment Plans</h3>
                            <a href="payments/index.php" class="btn btn-sm btn-primary">View All</a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Customer</th>
                                            <th>Paid</th>
                                            <th>Balance</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($active_plans as $plan): 
                                            $status = '';
                                            $days_passed = (new DateTime($plan['release_date']))->diff(new DateTime())->days;
                                            $expected_payment = $days_passed * $plan['daily_payment'];
                                            
                                            if ($plan['total_paid'] >= $plan['balance']) {
                                                $status = 'Completed';
                                            } elseif ($plan['total_paid'] >= $expected_payment) {
                                                $status = 'On Time';
                                            } else {
                                                $status = 'Delayed';
                                            }
                                        ?>
                                            <tr>
                                                <td><?= $plan['plan_id'] ?></td>
                                                <td><?= htmlspecialchars($plan['customer_name']) ?></td>
                                                <td><?= format_currency($plan['total_paid']) ?></td>
                                                <td>
                                                    <span class="status-badge status-<?= strtolower(str_replace(' ', '', $status)) ?>">
                                                        <?= format_currency($plan['remaining_balance']) ?>
                                                    </span>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Sidebar toggle
    document.getElementById('sidebarCollapse').addEventListener('click', function() {
        document.getElementById('sidebar').classList.toggle('active');
        document.getElementById('content').classList.toggle('active');
    });
</script>
</body>
</html>