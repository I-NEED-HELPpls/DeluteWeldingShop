<?php
require '../config.php';

// Get all payment plans with corrected calculations
$stmt = $pdo->query("
    SELECT 
        pp.plan_id, 
        pp.customer_name, 
        pp.total_amount, 
        pp.downpayment, 
        pp.balance,
        pp.daily_payment,
        pp.release_date,
        COALESCE(SUM(p.amount_paid), 0) as total_paid,
        (pp.balance - COALESCE(SUM(p.amount_paid), 0)) as remaining_balance
    FROM payment_plans pp 
    LEFT JOIN payments p ON pp.plan_id = p.plan_id 
    GROUP BY pp.plan_id 
    ORDER BY pp.release_date DESC
");
$plans = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate summary stats with proper validation
$total_collected = 0;
$total_outstanding = 0;
$total_plans = count($plans);
$completed_plans = 0;
$delayed_plans = 0;

foreach ($plans as $plan) {
    $total_collected += $plan['total_paid'];
    $total_outstanding += $plan['remaining_balance'];
    
    $days_passed = (new DateTime($plan['release_date']))->diff(new DateTime())->days;
    $expected_payment = $days_passed * $plan['daily_payment'];
    
    if ($plan['total_paid'] >= $plan['balance']) {
        $completed_plans++;
    } elseif ($plan['total_paid'] < $expected_payment) {
        $delayed_plans++;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delute Welding Shop - Payment Plans</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
<div class="wrapper">
    <!-- Sidebar -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <h3>Delute Welding Shop</h3>
            <p>Management System</p>
        </div>

        <div class="sidebar-menu">
            <ul class="list-unstyled components">
                <li>
                    <a href="../index.php">
                        <i class="bi bi-speedometer2"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="../orders/orders.php">
                        <i class="bi bi-clipboard-check"></i>
                        <span>Orders</span>
                    </a>
                </li>
                <li class="active">
                    <a href="index.php">
                        <i class="bi bi-cash-stack"></i>
                        <span>Payments</span>
                    </a>
                </li>
                <li>
                    <a href="../reports.php">
                        <i class="bi bi-graph-up"></i>
                        <span>Reports</span>
                    </a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Page Content -->
    <div id="content">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="mb-0">Payment Plans</h1>
                <div>
                    <a href="add_plan.php" class="btn btn-primary me-2">
                        <i class="bi bi-plus"></i> New Plan
                    </a>
                    <a href="add_payment.php" class="btn btn-success">
                        <i class="bi bi-cash"></i> Record Payment
                    </a>
                </div>
            </div>

            <!-- Stats Cards -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <div class="icon mb-3">
                                <i class="bi bi-credit-card fs-1 text-primary"></i>
                            </div>
                            <h6 class="card-title text-muted">Total Plans</h6>
                            <h3 class="mb-0"><?= number_format($total_plans) ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <div class="icon mb-3">
                                <i class="bi bi-cash fs-1 text-success"></i>
                            </div>
                            <h6 class="card-title text-muted">Total Collected</h6>
                            <h3 class="mb-0"><?= format_currency($total_collected) ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <div class="icon mb-3">
                                <i class="bi bi-currency-exchange fs-1 text-danger"></i>
                            </div>
                            <h6 class="card-title text-muted">Total Outstanding</h6>
                            <h3 class="mb-0"><?= format_currency($total_outstanding) ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <div class="icon mb-3">
                                <i class="bi bi-exclamation-triangle fs-1 text-warning"></i>
                            </div>
                            <h6 class="card-title text-muted">Delayed Plans</h6>
                            <h3 class="mb-0"><?= number_format($delayed_plans) ?></h3>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3 class="mb-0">All Payment Plans</h3>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Customer</th>
                                    <th>Release Date</th>
                                    <th>Total</th>
                                    <th>Paid</th>
                                    <th>Balance</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($plans as $plan): 
                                    $days_passed = (new DateTime($plan['release_date']))->diff(new DateTime())->days;
                                    $expected_payment = $days_passed * $plan['daily_payment'];
                                    
                                    if ($plan['total_paid'] >= $plan['balance']) {
                                        $status = 'Completed';
                                    } elseif ($plan['total_paid'] >= $expected_payment) {
                                        $status = 'On Time';
                                    } else {
                                        $status = 'Delayed';
                                    }
                                ?>
                                <tr>
                                    <td><?= $plan['plan_id'] ?></td>
                                    <td><?= htmlspecialchars($plan['customer_name']) ?></td>
                                    <td><?= date('M j, Y', strtotime($plan['release_date'])) ?></td>
                                    <td><?= format_currency($plan['total_amount']) ?></td>
                                    <td><?= format_currency($plan['total_paid']) ?></td>
                                    <td><?= format_currency($plan['remaining_balance']) ?></td>
                                    <td>
                                        <span class="status-badge status-<?= strtolower(str_replace(' ', '', $status)) ?>">
                                            <?= $status ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="view_plan.php?id=<?= $plan['plan_id'] ?>" class="btn btn-sm btn-outline-primary">
                                            <i class="bi bi-eye"></i> View
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Sidebar toggle
    document.getElementById('sidebarCollapse').addEventListener('click', function() {
        document.getElementById('sidebar').classList.toggle('active');
        document.getElementById('content').classList.toggle('active');
    });
</script>
</body>
</html>