<?php
require '../config.php';

$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-t');
$status_filter = $_GET['status'] ?? 'all';

$query = "SELECT
    pp.plan_id,
    pp.customer_name,
    pp.contact,
    pp.release_date,
    pp.total_amount,
    pp.downpayment,
    pp.balance,
    pp.daily_payment,
    COALESCE(SUM(p.amount_paid), 0) as total_paid,
    (pp.balance - COALESCE(SUM(p.amount_paid), 0)) as remaining_balance
    FROM payment_plans pp
    LEFT JOIN payments p ON pp.plan_id = p.plan_id
    WHERE pp.release_date BETWEEN ? AND ?";

$params = [$start_date, $end_date];

if ($status_filter !== 'all') {
    $query .= " GROUP BY pp.plan_id HAVING ";
    if ($status_filter === 'completed') {
        $query .= "total_paid >= pp.balance";
    } elseif ($status_filter === 'ontime') {
        $query .= "total_paid >= (DATEDIFF(CURDATE(), pp.release_date) * pp.daily_payment) AND total_paid < pp.balance";
    } elseif ($status_filter === 'delayed') {
        $query .= "total_paid < (DATEDIFF(CURDATE(), pp.release_date) * pp.daily_payment)";
    }
} else {
    $query .= " GROUP BY pp.plan_id";
}

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$plans = $stmt->fetchAll(PDO::FETCH_ASSOC);

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="delute_payment_plans_' . date('Y-m-d') . '.csv"');

$output = fopen('php://output', 'w');

fputcsv($output, [
    'Plan ID',
    'Customer Name',
    'Contact',
    'Release Date',
    'Total Amount',
    'Downpayment',
    'Balance',
    'Daily Payment',
    'Total Paid',
    'Remaining Balance',
    'Status'
]);

foreach ($plans as $plan) {
    $days_passed = (new DateTime($plan['release_date']))->diff(new DateTime())->days;
    $expected_payment = $days_passed * $plan['daily_payment'];

    if ($plan['total_paid'] >= $plan['balance']) {
        $status = 'Completed';
    } elseif ($plan['total_paid'] >= $expected_payment) {
        $status = 'On Time';
    } else {
        $status = 'Delayed';
    }

    fputcsv($output, [
        $plan['plan_id'],
        $plan['customer_name'],
        $plan['contact'],
        $plan['release_date'],
        $plan['total_amount'],
        $plan['downpayment'],
        $plan['balance'],
        $plan['daily_payment'],
        $plan['total_paid'],
        $plan['remaining_balance'],
        $status
    ]);
}

fclose($output);
exit;