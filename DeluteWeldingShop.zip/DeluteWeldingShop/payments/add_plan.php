<?php
require '../config.php';

// Get all customers with installment orders (not completed)
$stmt = $pdo->query("
    SELECT o.order_id, o.customer_name, o.contact, o.total_amount, o.downpayment 
    FROM orders o
    LEFT JOIN payment_plans pp ON o.order_id = pp.order_id
    WHERE o.payment_type = 'installment' 
    AND o.status != 'completed'
    AND pp.plan_id IS NULL
    ORDER BY o.customer_name
");
$installment_customers = $stmt->fetchAll(PDO::FETCH_ASSOC);

$order_id = $_GET['order_id'] ?? null;
$order = null;

if ($order_id) {
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE order_id = ?");
    $stmt->execute([$order_id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        header("Location: ../orders/orders.php");
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customer_name = $_POST['customer_name'];
    $contact = $_POST['contact'];
    $total_amount = $_POST['total_amount'];
    $downpayment = $_POST['downpayment'];
    $release_date = $_POST['release_date'];
    $preferred_mode = $_POST['preferred_mode'];
    $order_id = $_POST['order_id'] ?? null;
    
    $balance = $total_amount - $downpayment;
    $daily_payment = $balance / 540;
    
    $stmt = $pdo->prepare("INSERT INTO payment_plans (customer_name, contact, total_amount, downpayment, balance, daily_payment, release_date, preferred_mode, order_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$customer_name, $contact, $total_amount, $downpayment, $balance, $daily_payment, $release_date, $preferred_mode, $order_id]);
    
    if ($order_id) {
        $stmt = $pdo->prepare("UPDATE orders SET status = 'completed' WHERE order_id = ?");
        $stmt->execute([$order_id]);
        
        $stmt = $pdo->prepare("INSERT INTO order_updates (order_id, status, update_date) VALUES (?, 'completed', ?)");
        $stmt->execute([$order_id, date('Y-m-d')]);
    }
    
    header("Location: " . ($order_id ? "../orders/view_order.php?id=$order_id" : "index.php"));
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delute Welding Shop - <?= $order ? 'Create Payment Plan' : 'Add Payment Plan' ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
<div class="wrapper">
    <!-- Sidebar -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <h3>Delute Welding Shop</h3>
            <p>Management System</p>
        </div>

        <div class="sidebar-menu">
            <ul class="list-unstyled components">
                <li>
                    <a href="../index.php">
                        <i class="bi bi-speedometer2"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="../orders/orders.php">
                        <i class="bi bi-clipboard-check"></i>
                        <span>Orders</span>
                    </a>
                </li>
                <li class="active">
                    <a href="index.php">
                        <i class="bi bi-cash-stack"></i>
                        <span>Payments</span>
                    </a>
                </li>
                <li>
                    <a href="../reports.php">
                        <i class="bi bi-graph-up"></i>
                        <span>Reports</span>
                    </a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Page Content -->
    <div id="content">
        <div class="container-fluid">
            <div class="card">
                <div class="card-header">
                    <h2><?= $order ? "Payment Plan for Order #{$order['order_id']}" : 'New Payment Plan' ?></h2>
                </div>
                <div class="card-body">
                    <form method="post">
                        <?php if ($order): ?>
                        <input type="hidden" name="order_id" value="<?= $order['order_id'] ?>">
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5>Order Details</h5>
                                <p><strong>Customer:</strong> <?= htmlspecialchars($order['customer_name']) ?></p>
                                <p><strong>Total:</strong> <?= format_currency($order['total_amount']) ?></p>
                                <p><strong>Downpayment:</strong> <?= format_currency($order['downpayment']) ?></p>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <label for="customer_select" class="form-label">Select Customer with Installment Order</label>
                                <select class="form-select" id="customer_select">
                                    <option value="">Select a customer...</option>
                                    <?php foreach ($installment_customers as $customer): ?>
                                    <option value="<?= $customer['order_id'] ?>" 
                                        data-name="<?= htmlspecialchars($customer['customer_name']) ?>"
                                        data-contact="<?= htmlspecialchars($customer['contact']) ?>"
                                        data-total="<?= $customer['total_amount'] ?>"
                                        data-downpayment="<?= $customer['downpayment'] ?>">
                                        <?= htmlspecialchars($customer['customer_name']) ?> (Order #<?= $customer['order_id'] ?>)
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="customer_name" class="form-label">Customer Name</label>
                                <input type="text" class="form-control" id="customer_name" name="customer_name" 
                                    value="<?= $order ? htmlspecialchars($order['customer_name']) : '' ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label for="contact" class="form-label">Contact Number</label>
                                <input type="text" class="form-control" id="contact" name="contact" 
                                    value="<?= $order ? htmlspecialchars($order['contact']) : '' ?>" required>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="total_amount" class="form-label">Total Amount (₱)</label>
                                <input type="number" class="form-control" id="total_amount" name="total_amount" 
                                    value="<?= $order ? $order['total_amount'] : '' ?>" step="0.01" min="0" required>
                            </div>
                            <div class="col-md-6">
                                <label for="downpayment" class="form-label">Downpayment (₱)</label>
                                <input type="number" class="form-control" id="downpayment" name="downpayment" 
                                    value="<?= $order ? $order['downpayment'] : '0' ?>" step="0.01" min="0" required>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="release_date" class="form-label">Release Date</label>
                                <input type="date" class="form-control" id="release_date" name="release_date" required value="<?= date('Y-m-d') ?>">
                            </div>
                            <div class="col-md-6">
                                <label for="preferred_mode" class="form-label">Payment Mode</label>
                                <select class="form-select" id="preferred_mode" name="preferred_mode" required>
                                    <option value="Daily">Daily</option>
                                    <option value="15 Days">Every 15 Days</option>
                                    <option value="Monthly">Monthly</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="d-flex justify-content-end">
                            <a href="<?= $order ? "../orders/view_order.php?id={$order['order_id']}" : "index.php" ?>" class="btn btn-secondary me-2">
                                <i class="bi bi-x"></i> Cancel
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-check"></i> Create Plan
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Sidebar toggle
    document.getElementById('sidebarCollapse').addEventListener('click', function() {
        document.getElementById('sidebar').classList.toggle('active');
        document.getElementById('content').classList.toggle('active');
    });

    // Customer selection for new payment plans
    document.getElementById('customer_select')?.addEventListener('change', function() {
        const selectedOption = this.options[this.selectedIndex];
        if (selectedOption.value) {
            document.getElementById('customer_name').value = selectedOption.dataset.name;
            document.getElementById('contact').value = selectedOption.dataset.contact;
            document.getElementById('total_amount').value = selectedOption.dataset.total;
            document.getElementById('downpayment').value = selectedOption.dataset.downpayment;
        }
    });

    // Calculate balance when total or downpayment changes
    document.getElementById('total_amount').addEventListener('change', calculateBalance);
    document.getElementById('downpayment').addEventListener('change', calculateBalance);
    
    function calculateBalance() {
        const total = parseFloat(document.getElementById('total_amount').value) || 0;
        const downpayment = parseFloat(document.getElementById('downpayment').value) || 0;
        if (downpayment > total) {
            alert('Downpayment cannot be greater than total amount');
            document.getElementById('downpayment').value = '';
        }
    }
</script>
</body>
</html>