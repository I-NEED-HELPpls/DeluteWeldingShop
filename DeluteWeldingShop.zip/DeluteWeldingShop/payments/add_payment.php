<?php
require '../config.php';

// Get payment plans
$stmt = $pdo->query("SELECT plan_id, customer_name FROM payment_plans ORDER BY customer_name");
$plans = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Pre-selected plan
$plan_id = $_GET['plan_id'] ?? null;
$selected_plan = null;

if ($plan_id) {
    $stmt = $pdo->prepare("SELECT * FROM payment_plans WHERE plan_id = ?");
    $stmt->execute([$plan_id]);
    $selected_plan = $stmt->fetch(PDO::FETCH_ASSOC);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $plan_id = $_POST['plan_id'];
    $payment_date = $_POST['payment_date'];
    $amount_paid = $_POST['amount_paid'];
    $payment_mode = $_POST['payment_mode'];
    $payment_method = $_POST['payment_method'];
    $transaction_number = $_POST['transaction_number'] ?? null;
    $receipt_image = null;

    // Handle file upload
    if ($payment_method === 'GCash' && isset($_FILES['receipt_image']) && $_FILES['receipt_image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = '../uploads/receipts/';
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

        $filename = uniqid('gcash_') . "_" . basename($_FILES['receipt_image']['name']);
        $target_path = $upload_dir . $filename;

        if (move_uploaded_file($_FILES['receipt_image']['tmp_name'], $target_path)) {
            $receipt_image = $target_path;
        }
    }

    // Insert payment
    $stmt = $pdo->prepare("INSERT INTO payments (plan_id, payment_date, amount_paid, payment_mode, payment_method, transaction_number, receipt_image)
                           VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$plan_id, $payment_date, $amount_paid, $payment_mode, $payment_method, $transaction_number, $receipt_image]);

    header("Location: view_plan.php?id=$plan_id");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delute Welding Shop - Record Payment</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
<div class="wrapper">
    <nav id="sidebar">
        <div class="sidebar-header">
            <h3>Delute Welding Shop</h3>
            <p>Management System</p>
        </div>
        <div class="sidebar-menu">
            <ul class="list-unstyled components">
                <li><a href="../index.php"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
                <li><a href="../orders/orders.php"><i class="bi bi-clipboard-check"></i> Orders</a></li>
                <li class="active"><a href="index.php"><i class="bi bi-cash-stack"></i> Payments</a></li>
                <li><a href="../reports.php"><i class="bi bi-graph-up"></i> Reports</a></li>
            </ul>
        </div>
    </nav>

    <div id="content">
        <div class="container-fluid">
            <div class="card mt-4">
                <div class="card-header">
                    <h2>Record Payment</h2>
                </div>
                <div class="card-body">
                    <form method="post" enctype="multipart/form-data">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="plan_id" class="form-label">Payment Plan</label>
                                <select class="form-select" id="plan_id" name="plan_id" <?= $selected_plan ? 'disabled' : '' ?> required>
                                    <?php if ($selected_plan): ?>
                                    <option value="<?= $selected_plan['plan_id'] ?>" selected>
                                        <?= htmlspecialchars($selected_plan['customer_name']) ?> (ID: <?= $selected_plan['plan_id'] ?>)
                                    </option>
                                    <?php else: ?>
                                    <option value="">Select a plan...</option>
                                    <?php foreach ($plans as $plan): ?>
                                    <option value="<?= $plan['plan_id'] ?>"><?= htmlspecialchars($plan['customer_name']) ?> (ID: <?= $plan['plan_id'] ?>)</option>
                                    <?php endforeach; ?>
                                    <?php endif; ?>
                                </select>
                                <?php if ($selected_plan): ?>
                                <input type="hidden" name="plan_id" value="<?= $selected_plan['plan_id'] ?>">
                                <?php endif; ?>
                            </div>

                            <div class="col-md-6">
                                <label for="payment_date" class="form-label">Payment Date</label>
                                <input type="datetime-local" class="form-control" name="payment_date" required value="<?= date('Y-m-d\TH:i') ?>">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="amount_paid" class="form-label">Amount (₱)</label>
                                <input type="number" class="form-control" name="amount_paid" step="0.01" min="0" required>
                            </div>

                            <div class="col-md-6">
    <label for="payment_mode" class="form-label">Payment Mode</label>
    
    <?php if ($selected_plan): ?>
        <select class="form-select" id="payment_mode_display" disabled>
            <option selected><?= htmlspecialchars($selected_plan['preferred_mode']) ?></option>
        </select>
        <input type="hidden" name="payment_mode" value="<?= htmlspecialchars($selected_plan['preferred_mode']) ?>">
    <?php else: ?>
        <select class="form-select" id="payment_mode" name="payment_mode" required>
            <option value="Daily">Daily</option>
            <option value="15 Days">Every 15 Days</option>
            <option value="Monthly">Monthly</option>
        </select>
    <?php endif; ?>
</div>


                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="payment_method" class="form-label">Payment Method</label>
                                <select class="form-select" id="payment_method" name="payment_method" required>
                                    <option value="">Select</option>
                                    <option value="Cash">Cash</option>
                                    <option value="GCash">GCash</option>
                                </select>
                            </div>
                        </div>

                        <div id="gcash_fields" class="row mb-3 d-none">
                            <div class="col-md-6">
                                <label for="transaction_number" class="form-label">GCash Transaction Number</label>
                                <input type="text" class="form-control" name="transaction_number" placeholder="Enter GCash reference number">
                            </div>
                            <div class="col-md-6">
                                <label for="receipt_image" class="form-label">Upload GCash Receipt</label>
                                <input type="file" class="form-control" name="receipt_image" accept="image/*">
                            </div>
                        </div>

                        <div class="d-flex justify-content-end">
                            <a href="<?= $selected_plan ? 'view_plan.php?id=' . $selected_plan['plan_id'] : 'index.php' ?>" class="btn btn-secondary me-2">
                                <i class="bi bi-x"></i> Cancel
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-check"></i> Record Payment
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('payment_method').addEventListener('change', function () {
    const gcashFields = document.getElementById('gcash_fields');
    gcashFields.classList.toggle('d-none', this.value !== 'GCash');
});
</script>
</body>
</html>
