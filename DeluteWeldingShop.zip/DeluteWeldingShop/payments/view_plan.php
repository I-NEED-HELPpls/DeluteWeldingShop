<?php
require '../config.php';

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$plan_id = $_GET['id'];

// Get payment plan
$stmt = $pdo->prepare("SELECT * FROM payment_plans WHERE plan_id = ?");
$stmt->execute([$plan_id]);
$plan = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$plan) {
    header("Location: index.php");
    exit;
}

// Get payments
$stmt = $pdo->prepare("SELECT * FROM payments WHERE plan_id = ? ORDER BY payment_date DESC");
$stmt->execute([$plan_id]);
$payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate stats
$total_paid = array_sum(array_column($payments, 'amount_paid'));
$remaining_balance = $plan['balance'] - $total_paid;

$release_date = new DateTime($plan['release_date']);
$today = new DateTime();
$days_passed = $release_date->diff($today)->days;
$expected_payment = $days_passed * $plan['daily_payment'];

$days_paid = round($total_paid / $plan['daily_payment'], 2);
$days_remaining = max(540 - $days_paid, 0);

if ($total_paid >= $plan['balance']) {
    $status = 'Completed';
} elseif ($total_paid >= $expected_payment) {
    $status = 'On Time';
} else {
    $status = 'Delayed';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delute Welding Shop - Payment Plan #<?= $plan_id ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
<div class="wrapper">
    <!-- Sidebar -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <h3>Delute Welding Shop</h3>
            <p>Management System</p>
        </div>

        <div class="sidebar-menu">
            <ul class="list-unstyled components">
                <li>
                    <a href="../index.php">
                        <i class="bi bi-speedometer2"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="../orders/orders.php">
                        <i class="bi bi-clipboard-check"></i>
                        <span>Orders</span>
                    </a>
                </li>
                <li class="active">
                    <a href="index.php">
                        <i class="bi bi-cash-stack"></i>
                        <span>Payments</span>
                    </a>
                </li>
                <li>
                    <a href="../reports.php">
                        <i class="bi bi-graph-up"></i>
                        <span>Reports</span>
                    </a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Page Content -->
    <div id="content">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1>Payment Plan #<?= $plan_id ?></h1>
                <a href="index.php" class="btn btn-secondary">Back to Plans</a>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h3>Plan Details</h3>
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <h4><?= htmlspecialchars($plan['customer_name']) ?></h4>
                                <p class="text-muted"><?= $plan['contact'] ?></p>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-6">
                                    <p class="text-muted mb-1">Release Date</p>
                                    <p><?= date('M j, Y', strtotime($plan['release_date'])) ?></p>
                                </div>
                                <div class="col-6">
                                    <p class="text-muted mb-1">Preferred Mode</p>
                                    <p><?= $plan['preferred_mode'] ?></p>
                                </div>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-6">
                                    <p class="text-muted mb-1">Daily Payment</p>
                                    <p><?= format_currency($plan['daily_payment']) ?></p>
                                </div>
                                <div class="col-6">
                                    <p class="text-muted mb-1">Status</p>
                                    <p>
                                        <span class="status-badge status-<?= strtolower(str_replace(' ', '', $status)) ?>">
                                            <?= $status ?>
                                        </span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h3>Payment Summary</h3>
                        </div>
                        <div class="card-body">
                            <div class="row mb-3">
                                <div class="col-6">
                                    <p class="text-muted mb-1">Total Amount</p>
                                    <p><?= format_currency($plan['total_amount']) ?></p>
                                </div>
                                <div class="col-6">
                                    <p class="text-muted mb-1">Downpayment</p>
                                    <p><?= format_currency($plan['downpayment']) ?></p>
                                </div>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-6">
                                    <p class="text-muted mb-1">Total Paid</p>
                                    <p><?= format_currency($total_paid) ?></p>
                                </div>
                                <div class="col-6">
                                    <p class="text-muted mb-1">Remaining Balance</p>
                                    <p><?= format_currency($remaining_balance) ?></p>
                                </div>
                            </div>
                            
                            <div class="progress mb-3">
                                <div class="progress-bar" role="progressbar" 
                                     style="width: <?= min(100, ($days_paid / 540) * 100) ?>%" 
                                     aria-valuenow="<?= ($days_paid / 540) * 100 ?>" 
                                     aria-valuemin="0" 
                                     aria-valuemax="100">
                                </div>
                            </div>
                            <div class="d-flex justify-content-between">
                                <small><?= $days_paid ?> days paid</small>
                                <small><?= $days_remaining ?> days remaining</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="d-flex justify-content-between align-items-center mb-3">
    <h3>Payment History</h3>
    <?php if ($remaining_balance > 0): ?>
        <a href="add_payment.php?plan_id=<?= $plan_id ?>" class="btn btn-primary">
            <i class="bi bi-plus"></i> Add Payment
        </a>
    <?php endif; ?>
</div>


            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Amount</th>
                                    <th>Mode</th>
                                    <th>Method</th>
                                    <th>Days Covered</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($payments as $payment): ?>
                                <tr>
                                    <td><?= date('M j, Y', strtotime($payment['payment_date'])) ?></td>
                                    <td><?= format_currency($payment['amount_paid']) ?></td>
                                    <td><?= $payment['payment_mode'] ?></td>
                                    <td><?= $payment['payment_method'] ?></td>
                                    <td><?= round($payment['amount_paid'] / $plan['daily_payment'], 2) ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Sidebar toggle
    document.getElementById('sidebarCollapse').addEventListener('click', function() {
        document.getElementById('sidebar').classList.toggle('active');
        document.getElementById('content').classList.toggle('active');
    });
</script>
</body>
</html>