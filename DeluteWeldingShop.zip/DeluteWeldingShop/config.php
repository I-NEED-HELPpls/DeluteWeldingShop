<?php
$host = 'localhost';
$dbname = 'sidecar_tracker';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Could not connect to the database: " . $e->getMessage());
}

date_default_timezone_set('Asia/Manila');

// Helper functions
function format_currency($amount) {
    return '₱' . number_format($amount, 2);
}

function get_status_badge($status) {
    $status_map = [
        'completed' => 'success',
        'ontime' => 'primary',
        'delayed' => 'danger',
        'ordered' => 'secondary',
        'framing' => 'warning',
        'painting' => 'info',
        'finishing' => 'dark'
    ];
    $class = $status_map[strtolower($status)] ?? 'secondary';
    return '<span class="badge bg-'.$class.'">'.ucfirst($status).'</span>';
}
?>