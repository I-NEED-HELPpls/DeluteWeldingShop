<?php
require '../config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customer_name = $_POST['customer_name'];
    $contact = $_POST['contact'];
    $total_amount = $_POST['total_amount'];
    $payment_type = $_POST['payment_type'];
    $downpayment = $_POST['downpayment'] ?? 0;
    $order_date = $_POST['order_date'];
    $notes = $_POST['notes'];
    
    
    $stmt = $pdo->prepare("INSERT INTO orders (customer_name, contact, total_amount, payment_type, downpayment, order_date, notes) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$customer_name, $contact, $total_amount, $payment_type, $downpayment, $order_date, $notes]);
    
    $order_id = $pdo->lastInsertId();
    
    // Record initial status
    $stmt = $pdo->prepare("INSERT INTO order_updates (order_id, status, update_date) VALUES (?, 'ordered', ?)");
    $stmt->execute([$order_id, $order_date]);
    
    // If cash payment, mark as completed
   // If cash payment and fully paid, mark as completed
if ($payment_type === 'cash' && floatval($downpayment) >= floatval($total_amount)) {
    $stmt = $pdo->prepare("UPDATE orders SET status = 'completed' WHERE order_id = ?");
    $stmt->execute([$order_id]);

    $stmt = $pdo->prepare("INSERT INTO order_updates (order_id, status, update_date) VALUES (?, 'completed', ?)");
    $stmt->execute([$order_id, $order_date]);
}

    
    header("Location: view_order.php?id=$order_id");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delute Welding Shop - New Order</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
<div class="wrapper">
    <!-- Sidebar -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <h3>Delute Welding Shop</h3>
            <p>Management System</p>
        </div>

        <div class="sidebar-menu">
            <ul class="list-unstyled components">
                <li>
                    <a href="../index.php">
                        <i class="bi bi-speedometer2"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="orders.php">
                        <i class="bi bi-clipboard-check"></i>
                        <span>Orders</span>
                    </a>
                </li>
                <li>
                    <a href="../payments/index.php">
                        <i class="bi bi-cash-stack"></i>
                        <span>Payments</span>
                    </a>
                </li>
                <li>
                    <a href="../reports.php">
                        <i class="bi bi-graph-up"></i>
                        <span>Reports</span>
                    </a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Page Content -->
    <div id="content">
        <div class="container-fluid">
            <div class="card">
                <div class="card-header">
                    <h2>New Order</h2>
                </div>
                <div class="card-body">
                    <form method="post">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="customer_name" class="form-label">Customer Name</label>
                                <input type="text" class="form-control" id="customer_name" name="customer_name" required>
                            </div>
                            <div class="col-md-6">
                                <label for="contact" class="form-label">Contact Number</label>
                                <input type="text" class="form-control" id="contact" name="contact" required>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="total_amount" class="form-label">Total Amount (₱)</label>
                                <input type="number" class="form-control" id="total_amount" name="total_amount" 
                                       step="0.01" min="0" required>
                            </div>
                            <div class="col-md-6">
                                <label for="payment_type" class="form-label">Payment Type</label>
                                <select class="form-select" id="payment_type" name="payment_type" required>
                                    <option value="installment">Installment</option>
                                    <option value="cash">Cash</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="row mb-3" id="downpayment-row">
                            <div class="col-md-6">
                                <label for="downpayment" class="form-label">Downpayment (₱)</label>
                                <input type="number" class="form-control" id="downpayment" name="downpayment" 
                                       step="0.01" min="0" value="0">
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="order_date" class="form-label">Order Date</label>
                                <input type="datetime-local" class="form-control" id="order_date" name="order_date" 
                                       required value="<?= date('Y-m-d\TH:i') ?>">
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="notes" class="form-label">Order Notes</label>
                            <textarea class="form-control" id="notes" name="notes" rows="3"></textarea>
                        </div>
                        
                        <div class="d-flex justify-content-end">
                            <a href="orders.php" class="btn btn-secondary me-2">
                                <i class="bi bi-x"></i> Cancel
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-check"></i> Create Order
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Sidebar toggle
    document.getElementById('sidebarCollapse').addEventListener('click', function() {
        document.getElementById('sidebar').classList.toggle('active');
        document.getElementById('content').classList.toggle('active');
    });

    // Handle payment type change
    document.getElementById('payment_type').addEventListener('change', function() {
    const paymentType = this.value;
    const downpaymentInput = document.getElementById('downpayment');
    const totalAmountInput = document.getElementById('total_amount');

    downpaymentInput.readOnly = false; // Always allow editing

    if (paymentType === 'cash') {
        // Optional: prefill downpayment with total if not set
        if (!downpaymentInput.value || parseFloat(downpaymentInput.value) === 0) {
            downpaymentInput.value = totalAmountInput.value;
        }
        } else {
            // For installment, allow editing downpayment
            downpaymentInput.readOnly = false;
        }
    });

    // Update downpayment when total amount changes for cash payments
    document.getElementById('total_amount').addEventListener('change', function() {
        if (document.getElementById('payment_type').value === 'cash') {
            document.getElementById('downpayment').value = this.value;
        }
    });
</script>
</body>
</html>