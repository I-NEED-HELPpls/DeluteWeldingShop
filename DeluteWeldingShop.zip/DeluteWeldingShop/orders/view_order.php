<?php
require '../config.php';

if (!isset($_GET['id'])) {
    header("Location: orders.php");
    exit;
}

$order_id = $_GET['id'];

// Get order details
$stmt = $pdo->prepare("SELECT * FROM orders WHERE order_id = ?");
$stmt->execute([$order_id]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    header("Location: orders.php");
    exit;
}

// Get status updates
$stmt = $pdo->prepare("SELECT * FROM order_updates WHERE order_id = ? ORDER BY update_date DESC");
$stmt->execute([$order_id]);
$updates = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Check for payment plan
$stmt = $pdo->prepare("SELECT * FROM payment_plans WHERE order_id = ?");
$stmt->execute([$order_id]);
$payment_plan = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delute Welding Shop - Order #<?= $order['order_id'] ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
<div class="wrapper">
    <!-- Sidebar -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <h3>Delute Welding Shop</h3>
            <p>Management System</p>
        </div>

        <div class="sidebar-menu">
            <ul class="list-unstyled components">
                <li>
                    <a href="../index.php">
                        <i class="bi bi-speedometer2"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="orders.php">
                        <i class="bi bi-clipboard-check"></i>
                        <span>Orders</span>
                    </a>
                </li>
                <li>
                    <a href="../payments/index.php">
                        <i class="bi bi-cash-stack"></i>
                        <span>Payments</span>
                    </a>
                </li>
                <li>
                    <a href="../reports.php">
                        <i class="bi bi-graph-up"></i>
                        <span>Reports</span>
                    </a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Page Content -->
    <div id="content">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1>Order #<?= $order['order_id'] ?></h1>
                <a href="orders.php" class="btn btn-secondary">
                    <i class="bi bi-arrow-left"></i> Back to Orders
                </a>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h3>Order Details</h3>
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <h4><?= htmlspecialchars($order['customer_name']) ?></h4>
                                <p class="text-muted"><?= $order['contact'] ?></p>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-6">
                                    <p class="text-muted mb-1">Order Date</p>
                                    <p><?= date('F j, Y', strtotime($order['order_date'])) ?></p>
                                </div>
                                <div class="col-6">
                                    <p class="text-muted mb-1">Status</p>
                                    <p><?= get_status_badge($order['status']) ?></p>
                                </div>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-6">
                                    <p class="text-muted mb-1">Total Amount</p>
                                    <p><?= format_currency($order['total_amount']) ?></p>
                                </div>
                                <div class="col-6">
                                    <p class="text-muted mb-1">Downpayment</p>
                                    <p><?= format_currency($order['downpayment']) ?></p>
                                </div>
                            </div>
                            
                            <?php if ($order['notes']): ?>
                            <div class="mb-3">
                                <p class="text-muted mb-1">Notes</p>
                                <p><?= nl2br(htmlspecialchars($order['notes'])) ?></p>
                            </div>
                            <?php endif; ?>
                            
                            <?php if ($order['status'] !== 'completed'): ?>
                            <div class="mt-4">
                                <a href="update_order.php?id=<?= $order['order_id'] ?>" class="btn btn-warning">
                                    <i class="bi bi-pencil"></i> Update Status
                                </a>
                            </div>
                            <?php elseif ($payment_plan): ?>
                            <div class="mt-4">
                                <a href="../payments/view_plan.php?id=<?= $payment_plan['plan_id'] ?>" class="btn btn-primary">
                                    <i class="bi bi-cash"></i> View Payment Plan
                                </a>
                            </div>
                            <?php else: ?>
                            <div class="mt-4">
                                <a href="../payments/add_plan.php?order_id=<?= $order['order_id'] ?>" class="btn btn-primary">
                                    <i class="bi bi-cash"></i> Create Payment Plan
                                </a>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h3>Status History</h3>
                        </div>
                        <div class="card-body">
                            <div class="timeline">
                                <?php foreach ($updates as $update): ?>
                                <div class="timeline-item">
                                    <div class="timeline-marker"></div>
                                    <div class="timeline-content">
                                        <p class="mb-1 fw-bold"><?= ucfirst($update['status']) ?></p>
                                        <p class="text-muted small"><?= date('M j, Y h:i A', strtotime($update['update_date'])) ?></p>
                                        <?php if ($update['notes']): ?>
                                        <p><?= nl2br(htmlspecialchars($update['notes'])) ?></p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Sidebar toggle
    document.getElementById('sidebarCollapse').addEventListener('click', function() {
        document.getElementById('sidebar').classList.toggle('active');
        document.getElementById('content').classList.toggle('active');
    });
</script>
</body>
</html>