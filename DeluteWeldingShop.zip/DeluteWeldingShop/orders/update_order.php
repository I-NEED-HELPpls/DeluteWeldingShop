<?php
require '../config.php';

if (!isset($_GET['id'])) {
    header("Location: orders.php");
    exit;
}

$order_id = $_GET['id'];

// Get order details
$stmt = $pdo->prepare("SELECT * FROM orders WHERE order_id = ?");
$stmt->execute([$order_id]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    header("Location: orders.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $status = $_POST['status'];
    $update_date = $_POST['update_date'];
    $notes = $_POST['notes'];
    
    // Update order status
    $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE order_id = ?");
    $stmt->execute([$status, $order_id]);
    
    // Record status update
    $stmt = $pdo->prepare("INSERT INTO order_updates (order_id, status, update_date, notes) VALUES (?, ?, ?, ?)");
    $stmt->execute([$order_id, $status, $update_date, $notes]);
    
    header("Location: view_order.php?id=$order_id");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delute Welding Shop - Update Order</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
<div class="wrapper">
    <!-- Sidebar -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <h3>Delute Welding Shop</h3>
            <p>Management System</p>
        </div>

        <div class="sidebar-menu">
            <ul class="list-unstyled components">
                <li>
                    <a href="../index.php">
                        <i class="bi bi-speedometer2"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="orders.php">
                        <i class="bi bi-clipboard-check"></i>
                        <span>Orders</span>
                    </a>
                </li>
                <li>
                    <a href="../payments/index.php">
                        <i class="bi bi-cash-stack"></i>
                        <span>Payments</span>
                    </a>
                </li>
                <li>
                    <a href="../reports.php">
                        <i class="bi bi-graph-up"></i>
                        <span>Reports</span>
                    </a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Page Content -->
    <div id="content">
        <div class="container-fluid">
            <div class="card">
                <div class="card-header">
                    <h2>Update Order Status</h2>
                </div>
                <div class="card-body">
                    <div class="mb-4">
                        <h4>Order #<?= $order['order_id'] ?></h4>
                        <p>Customer: <?= htmlspecialchars($order['customer_name']) ?></p>
                        <p>Current Status: <?= get_status_badge($order['status']) ?></p>
                    </div>
                    
                    <form method="post">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="status" class="form-label">New Status</label>
                                <select class="form-select" id="status" name="status" required>
                                    <option value="framing" <?= $order['status'] === 'ordered' ? '' : 'disabled' ?>>Framing</option>
                                    <option value="painting" <?= in_array($order['status'], ['ordered', 'framing']) ? '' : 'disabled' ?>>Painting</option>
                                    <option value="finishing" <?= in_array($order['status'], ['ordered', 'framing', 'painting']) ? '' : 'disabled' ?>>Finishing</option>
                                    <option value="completed" <?= in_array($order['status'], ['ordered', 'framing', 'painting', 'finishing']) ? '' : 'disabled' ?>>Completed</option>
                                </select>
                                <small class="text-muted">Status must progress in order</small>
                            </div>
                            <div class="col-md-6">
                                <label for="update_date" class="form-label">Update Date</label>
                                <input type="datetime-local" class="form-control" id="update_date" name="update_date" 
                                       required value="<?= date('Y-m-d\TH:i') ?>">
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="notes" class="form-label">Update Notes</label>
                            <textarea class="form-control" id="notes" name="notes" rows="3"></textarea>
                        </div>
                        
                        <div class="d-flex justify-content-end">
                            <a href="view_order.php?id=<?= $order_id ?>" class="btn btn-secondary me-2">
                                <i class="bi bi-x"></i> Cancel
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-check"></i> Update Status
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Sidebar toggle
    document.getElementById('sidebarCollapse').addEventListener('click', function() {
        document.getElementById('sidebar').classList.toggle('active');
        document.getElementById('content').classList.toggle('active');
    });
</script>
</body>
</html>